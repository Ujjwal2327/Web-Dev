#include<iostream>
using namespace std;

void bubblesort(){
    //
}

void quick(){
    // 
}

void mergesort(){
    // 
}

void insertionsort(){
    // 
}

int main(){

    cout<<"hello world\n";
    cout<<"hello .dot batch\n";

    return 0;
}